import Link from "next/link";
import { EnhancedHero } from "@/components/landing/EnhancedHero";
import { HowItWorks } from "@/components/landing/HowItWorks";
import { SiteHeader } from "@/components/landing/SiteHeader";
import { Button } from "@/components/ui/button";

export default function HomePage() {
  return (
    <div className="min-h-screen flex flex-col">
      <SiteHeader />
      <main className="flex-1">
        <EnhancedHero />
        <section id="how-it-works">
          <HowItWorks />
        </section>
        <section className="border-t bg-muted/30 py-16">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-2xl font-bold mb-4">Ready to save on your medical bills?</h2>
            <p className="text-muted-foreground mb-6 max-w-xl mx-auto">
              Take our 2-minute qualification quiz to see your estimated savings. No commitment.
            </p>
            <Button asChild size="lg" variant="yellow">
              <Link href="/get-started">Get Started — It&apos;s Free</Link>
            </Button>
          </div>
        </section>
      </main>
      <footer className="border-t py-8 text-center text-sm text-muted-foreground">
        <div className="container mx-auto px-4">
          <p>© {new Date().getFullYear()} BillRelief.com. HIPAA Compliant. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
